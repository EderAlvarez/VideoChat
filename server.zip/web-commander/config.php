<?php
return array(
    "username"      => "admin",
    "password"      => "admin",
    "p_sig"         => "chat-server",
    "start_cmd"     => "php ../bin/chat-server.php",
    "stop_cmd"      => "pkill -9 -f chat-server",
    "log_file"      => "web-commander.log"
);
