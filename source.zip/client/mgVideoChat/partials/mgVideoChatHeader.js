/**
 * mgVideoChat
 *
 * @version 1.13.2
 * @copyright magnoliyan
 */
