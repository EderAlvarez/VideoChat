#!/bin/sh

cat mgVideoChatHeader.js mgRtc.js mgFileHelper.js mgNotifications.js mgDesktopShare.js mgVideoChatUtils.js mgVideoChatRtcEvents.js mgVideoChatUI.js mgVideoChatBase.js > ../mgVideoChat.js